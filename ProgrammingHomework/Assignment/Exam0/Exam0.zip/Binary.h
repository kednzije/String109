extern void sum_len(char* str1, char* str2);
extern void merge(char* str1, char* str2);