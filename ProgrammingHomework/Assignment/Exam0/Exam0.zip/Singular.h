extern void get_min_asc(char *str);
extern void reorder(char *str);